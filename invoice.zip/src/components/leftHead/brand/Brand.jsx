import React from "react";

function Brand() {
  return (
    <div>
      <img src="../../img/logo.png" alt="logo" />
    </div>
  );
}

export default Brand;
