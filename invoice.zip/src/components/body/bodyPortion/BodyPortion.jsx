import React from "react";
import MenuPortion from "../headPortion/MenuPortion";
import FormData from "./Formdata";
function BodyPortion() {
  return (
    <div>
      <MenuPortion />
      <FormData />
    </div>
  );
}

export default BodyPortion;
