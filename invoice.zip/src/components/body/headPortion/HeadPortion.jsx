import React from "react";
import "./headPortion.css";

function HeadPortion() {
  return (
    <p className="fancy">
      <span>BILL DETAILS</span>
    </p>
  );
}

export default HeadPortion;
